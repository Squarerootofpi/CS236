#include "DatalogProgram.h"



//DatalogProgram::DatalogProgram()
//{
//}



