#ifndef TUPLE_H
#define TUPLE_H
#include<vector>
#include<sstream>

class Tuple : public std::vector<std::string>
{
public:
	Tuple(std::vector<string> strings) {
		for (string str : strings) {
			this->push_back(str); //pushback each string of the vector you pass into the tuple
		}
	}
	~Tuple() {

	}
	string test()
	{
		
		return "";
	}
	//write it
	string toString() {
		return this->toString();
		std::ostringstream os;
		for (unsigned int i = 0; i < this->size(); ++i)
		{
			os << this->at(i) << " ";
		}
		return os.str();
	}
	unsigned int find(string toFind)
	{
		for (unsigned int i = 0; i < this->size(); ++i)
		{
			if (this->at(i) == toFind)
			{
				return i;
			}
		}
		return 9999999;
	}
};

#endif // !TUPLE_H
