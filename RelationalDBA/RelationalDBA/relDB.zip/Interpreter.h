#ifndef INTERPRETER_H
#define INTERPRETER_H
#include"DatalogProgram.h"
#include"Relation.h"
#include"Database.h"
#include<map>
//This class converts the datalog into a database, and the database calls relational queries etc. 
using std::pair;

class Interpreter
{
	DatalogProgram datalog;
	Database db;
public:
	Interpreter(DatalogProgram data) : datalog(data) {

		//Database tempDB;
		//db = tempDB;
		//Make a relation for each scheme Predicate
		//put each relation in the database in the database data member


		vector<Predicate> schemes = datalog.getSchemes();
		string schemeName;
		for (unsigned int i = 0; i < schemes.size(); ++i)
		{
			schemeName = schemes.at(i).getName();
			Tuple newTuple(schemes.at(i).getParams());
			Relation newRelation(schemeName, newTuple);
			db.insert(pair<string, Relation>(schemeName, newRelation)); //Put the relation in database

			//cout << "New Relation " << endl;

		}
		//assuming all facts are defined already as a relation, not error checking
		string factName;
		vector<Predicate> facts = datalog.getFacts();
		//make a tuple for each fact predicate
		for (unsigned int i = 0; i < facts.size(); ++i)
		{
			factName = facts.at(i).getName();
			Tuple newTuple(facts.at(i).getParams());
			//Add to the relation for that fact
			db.at(factName).addTuple(newTuple); //Gets the relation associated with that factname/tuple
		}

		//Get the rules, and evaluate! :)
		string headPredName;
		vector<Rule> rules = datalog.getRules();

		//psuedo code for relational database rule evaluator 1 :)
		/*
		//while tuples added is true
			//for each rule
				//store the name of head pred
				//store the params of head pred

				//for each associate
					//pull out the name
					//pull out the string params
					//return a query relation
					DELETED//if another associate query was made before, join the two
				added://JOIN all the associate queries.
				//project the params of the head predicate from the joined associates
						
				//try to insert the tuples into the relation that has the name of the head pred
				//if inserted successfully,
					//set bool added tuples to true
				//if not, just continue to the next rule
		
			//(automatically) if tuplesAdded = true, continue, if no tuples added, break.
		*/
		

		cout << "Rule Evaluation" << endl;
		//variables for rule evaluations
		vector<string> headParams;
		vector<string> depParams;
		bool tuplesAdded = true;
		string headName;
		string ruleName;
		int passes = 0;
		//while tuples added is true
		while (tuplesAdded)
		{
			tuplesAdded = false; //Assume there will be no tuples added initially. 
			//for each rule
			for (Rule rule : rules)
			{
				cout << rule.toString() << "." << endl;
				//cout << " in for rules";
				//store the name of head pred
				headName = rule.getHeadREL().getName();
				//store the params of head pred
				headParams = rule.getHeadREL().getParams(); //Or ID's, or expression, depending on which vector

				vector<Relation> dependents;

				//for each associate
				for (Predicate assoc : rule.getAssocREL())
				{
					//pull out the name
					ruleName = assoc.getName();
					//pull out the string params
					depParams = assoc.getParams();
					//return a query relation
					//push the relation into the dependents
					dependents.push_back(doQuery(ruleName, depParams));
					
				}
				//join dependents
				Relation joined = dependents.at(0); 
				//cout << joined.size() << " joined size after dependence";
				for (unsigned int i = 1; i < dependents.size(); i++)
				{
					joined = joined.join(dependents.at(i));
				}
				//project the params of the head predicate from the joined associates
				
				vector<unsigned int> projVec;
				for (unsigned int i = 0; i < headParams.size(); i++) //for each param
				{
					projVec.push_back(joined.getSchemeREL().find(headParams.at(i)));
				}
				joined = joined.project(projVec);

				
				/*
				for ()
				{
					it = vars.find(headParams.at(i));

					if (it == vars.end()) //Not present in map! :)
					{
						//cout << "NOT present in map."; //So insert into map
						vars.insert(pair<string, unsigned int>(headParams.at(i), i));
						//i is the column we are on, so that's the index to project
					}
				}
				*/
				Tuple headScheme = db.at(headName).getSchemeREL();
				joined.changeScheme(headScheme);
				
				//try to insert the tuples into the relation that has the name of the head pred
				//for each tuple in the joined set,
				//cout << joined.size() << " is joined's size";
				for (const Tuple& tuple : joined.getTuples()) //
				{
					//cout << "in for joined gettuples";
					//if inserted successfully,
					if (db.at(headName).addTuple(tuple))
					{
						//output the tuple added
						//set bool added tuples to true
						tuplesAdded = true;
						if (!(tuple.size() == 0))
						{
							cout << "  ";
						}
						for (unsigned int i = 0; i < tuple.size(); ++i)
							//you could also do scheme.size(), since they are the same, 
							//and tuple is representative of one tuple in it.
						{
							cout << headScheme.at(i) << "=" << tuple.at(i);
							if (i < headScheme.size() - 1)
							{
								cout << ", ";
							}
							else
							{
								cout << endl;
							}
						}
					}
				}
				//output the evaluation of the rule. 
				/*
				Output a line with the text 'Rule Evaluation' followed by the output from evaluating each rule.

					For each rule that is evaluated, output the rule itself, followed by the tuples generated by the rule. 
					Output the rule in the same form that it appears in a Datalog program. Output each tuple in the same form 
					used by the query output in the previous project. Output the tuples after the last step of the evaluation of the rule, 
					after the attributes have been renamed to be union compatible with the relation that matches the head of the rule. 
					Only output the tuples that don't already exist in the result relation.

					After outputting all the evaluated rules, output a blank line followed by a line with the string,

					Schemes populated after n passes through the Rules.
					where n is the number of times the fixed-point algorithm repeated the rule evaluation.
				*/
			}
			//(automatically at end of loop) if tuplesAdded = true, continue, 
			//if no tuples added, break.
			passes++;
		}
		cout << endl << "Schemes populated after " << passes << " passes through the Rules." << endl;
		
		//end rule evaluations


		//Evaluate queries by calling doQuery

		/*
		Make a function in the Interpreter that evaluates one query predicate and returns a relation
		Make a function in the Interpreter that evaluates all queries

		*/
		cout << endl;
		cout << "Query Evaluation" << endl;
		string queryToString;
		vector<Predicate> queries = datalog.getQueries();
		for (unsigned int i = 0; i < queries.size(); ++i)
		{
			//cout << "Query" << i << endl; //This does each query...
			Relation endRelation = doQuery(queries.at(i).getName(), queries.at(i).getParams()); //Returns the tostring associated with the doquery
			queryToString = endRelation.toString();
			if (queryToString != "empty")
			{ 
				cout << queries.at(i).toString() << "? Yes(" << endRelation.size() << ")" << endl; //Yes(2)
				cout << queryToString;
			}
			else
			{
				cout << queries.at(i).toString() << "? No" << endl;

				//cout << "Empty Relation Returned " << endl;

			}
		}
		
		//Test of project function
		vector<unsigned int> toProject;
		toProject.push_back(0);
		toProject.push_back(1);
		toProject.push_back(2);

		//project(db.at(queries.at(0).getName()), toProject);
	}
	//Returns the relation from the query
	Relation doQuery(string name, vector<string> params)
	{
		//Cases:
		//Empty facts?
		std::map<string, unsigned int> vars;
		std::map<string, unsigned int>::iterator it; //iterator starting at beginning.
		
		//The db relation: Just a copy of it
		Relation dbRel(db.at(name));
		//Go through each parameter in query, and do appropriate stuff
		//unsigned int projindex = 0;
		for (unsigned int i = 0; i < params.size(); ++i)
		{
			//Select stuff:
			//if a constant
			if (isConstant(params.at(i)))
			{
				//cout << params.at(i) << ": constant. ";
				dbRel = dbRel.selectConst(i, params.at(i));
			}
			else //it is a variable
			{
				//cout << params.at(i) << ": variable ";

				//if in the map, do select with it and that other index
				it = vars.find(params.at(i));
				
				if (it == vars.end()) //Not present in map! :)
				{
					//cout << "NOT present in map."; //So insert into map
					vars.insert(pair<string, unsigned int>(params.at(i), i)); 
					//i is the column we are on, so that's the index to project
				}
				else
				{
					//cout << "present in map.";
					//	<< it->first << "->" << it->second;
					//Do selectCols with them both: both of the ints.
					dbRel = dbRel.selectCols(i, it->second); //Changed colIndex from i

				}
				//++projindex;

			}
			//Do Projects and Renames, once gone through everthing.

				//Rename columns
			



		}

		/*it = vars.begin(); //I couldn't get this one to work.... :(
		for (; it == vars.end(); it++)
		{
			
		}*/
		for (auto pair : vars)
		{
			dbRel = dbRel.renameCol(pair.first, pair.second);
			//cout << dbRel.toString();
		}
		//Get the ints into a vector
		vector<unsigned int> cols;
		for (unsigned int i = 0; i < params.size(); i++) //changed params.size from cols.size;
		{
			//int l = 0;
			for (auto pair : vars) //This double for loop is to push the vector 
								   //in the right order.
			{
				if (i == pair.second)
				{
					cols.push_back(pair.second);
				}
			}
		}
		//If someone wanted to see the things that were constant, include this.
		/*if (vars.size() == 0)
		{
			return dbRel;
		}*/
		dbRel = dbRel.project(cols);

		
		return dbRel;
	}


	//if parameter is aconstant
	bool isConstant(string parameter)
	{
		if (parameter.at(0) == '\'') //We know it is a constant
		{
			return true;
		}
		return false;
	}
	~Interpreter() {

	}
	//To be made if need to add relations later for some reason.
	void addRelation() {
		
		return;
	}
	string toString()
	{
		//for (auto)
		//datalog.toString() + 
		return db.toString();
	}

};

#endif //INTERPRETER_H